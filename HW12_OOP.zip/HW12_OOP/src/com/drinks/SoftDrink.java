package com.drinks;

public class SoftDrink {

	protected String name;
	protected double sugar;
	protected double ph;
	protected String ManufacturingDate;
	protected String color;
	protected double price;

	public SoftDrink() {
		price = 7.0;
		name = "unknown";
		sugar = 0;
		ph = 7;
		ManufacturingDate = "12.7.2018";
	}

	public String getManufacturingDate() {
		return ManufacturingDate;
	}

	public void setManufacturingDate(String manufacturingDate) {
		ManufacturingDate = manufacturingDate;
	}

	public String getColor() {
		return color;
	}

	public double getPrice() {
		return price;
	}

}
