package com.drinks;

public class Cola extends SoftDrink {

	private String secretRecipe;
	private String Advertising;
	private static int counter;

	public String getAdvertising() {
		return Advertising;
	}

	public static int getCounter() {
		return counter;
	}

	public Cola() {
		name = "Cola";
		sugar = 100;
		ph = 3.7;
		ManufacturingDate = "12.7.2018";
		color = "Black";
		price = 5.5;
		counter++;
	}

}
