package com.drinks;

public class DietCola extends Cola {

	public DietCola() {
		name = "DietCola";
		sugar = 0;
	}

}
