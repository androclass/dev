package com.drinks;

public class Mirinda extends SoftDrink {

	public void testFunction() {
		price = 6;
	}

}
