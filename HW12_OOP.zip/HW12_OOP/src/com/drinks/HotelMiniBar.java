package com.drinks;

public class HotelMiniBar {

	private int mMaxCapacity = 5;

	private SoftDrink[] mDrinks;
	double tmp;

	private double ExcessivePriceFactor = 1.5;

	public void clear() {
		for (int i = 0; i >= mMaxCapacity; i++) {
			if (mDrinks[i] != null) {
				mDrinks[i] = null;
			}
		}

		System.out.println("The Mini Bar Empty...");
	}

	public void refill(SoftDrink[] drinks) {
		for (int i = 0; i < mMaxCapacity; i++) {
			if (mDrinks[i] == null) {
				mDrinks[i] = drinks[i];
			}
		}

		System.out.println("The Mini Bar is Full...");
	}

	public void test() {
		Cola cola = new Cola();
		cola.name = "Colla";
	}

	// this is a constructor of HotelMiniBar class, we will learn about next
	// week
	public HotelMiniBar() {
		mDrinks = new SoftDrink[mMaxCapacity];
		tmp = -4.2;
	}

	public void putDrinks(SoftDrink[] drinks) {
		int size = drinks.length;

		if (size > mMaxCapacity) {
			size = mMaxCapacity;
		}

		for (int i = 0; i < size; i++) {
			mDrinks[i] = drinks[i];
		}
		System.out.println("Number of Drinks: " + mDrinks.length);
	}

	public SoftDrink getDrink() {
		if (mDrinks[0] != null) {
			SoftDrink drink = mDrinks[0];
			drink.price = drink.price * ExcessivePriceFactor;
			return drink;
		} else {
			System.out.println("Empty...");
			return null;
		}
	}

}
