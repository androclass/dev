package com.main;

import com.drinks.Cola;
import com.drinks.SoftDrink;

public class Refrigerator extends SoftDrink {

	public void test() {
		Cola cola = new Cola();

	}

}
