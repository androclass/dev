package com.main;

import com.drinks.*;

public class Main {

	public static void main(String[] args) {
		// Add your code here
		System.out.println("Keep calm and let's have a drink");
		Cola cola1 = new Cola();
		Cola cola2 = new Cola();
		Cola cola3 = new Cola();
		DietCola dietCole = new DietCola();
		System.out.println("Number of Colas: " + Cola.getCounter());
		HotelMiniBar mini = new HotelMiniBar();
		SoftDrink[] drinks = new SoftDrink[3];
		drinks[0] = cola1;
		drinks[1] = cola1;
		drinks[2] = cola1;
		mini.putDrinks(drinks);
		
		SoftDrink[] drinksRefill = new SoftDrink[5];
		drinksRefill[0] = new RedBull();
		drinksRefill[1] = new RedBull();
		drinksRefill[2] = new RedBull();
		drinksRefill[3] = new RedBull();
		drinksRefill[4] = new RedBull();
		mini.clear();
		mini.refill(drinksRefill);
	}

}
