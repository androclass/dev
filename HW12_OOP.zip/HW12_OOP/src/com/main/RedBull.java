package com.main;

import com.drinks.Cola;
import com.drinks.SoftDrink;

public class RedBull extends SoftDrink {
	
public RedBull(){
	name = "RedBull";
}
	
	public void test() {

	}
}
